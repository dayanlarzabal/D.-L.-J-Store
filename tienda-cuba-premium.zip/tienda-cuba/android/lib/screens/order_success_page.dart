import 'package:flutter/material.dart';

import '../models/models.dart';
import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';

/// Texto del comprobante que el cliente envía al vendedor por WhatsApp.
String orderMessage(OrderRecord o) {
  final items = o.lines.map((l) => '• ${l.name} ×${l.qty}').join('\n');
  final amount = '${moneyPlain(o.amount, o.method.decimals)} ${o.method.currencyCode}';
  final refLabel = o.method.isCrypto ? 'TXID' : 'Nº transacción';
  return 'Hola, acabo de pagar mi pedido ${o.code}.\n\n$items\n\n'
      'Método: ${o.method.label}\nMonto: $amount\n$refLabel: ${o.reference}\n'
      'Nombre: ${o.customerName}\nTeléfono: ${o.phone}'
      '${o.address.isEmpty ? '' : '\nDirección: ${o.address}'}';
}

class OrderSuccessPage extends StatelessWidget {
  final OrderRecord order;
  const OrderSuccessPage({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final wa = onlyDigits(store.cfg.whatsapp);

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 30, 24, 30),
          children: [
            Center(
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: 1),
                duration: const Duration(milliseconds: 700),
                curve: Curves.elasticOut,
                builder: (_, t, child) => Transform.scale(scale: t, child: child),
                child: Container(
                  width: 104,
                  height: 104,
                  decoration: BoxDecoration(
                    gradient: Palette.coralGradient,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                          color: Palette.coral.withOpacity(0.4),
                          blurRadius: 30,
                          offset: const Offset(0, 14)),
                    ],
                  ),
                  child: const Icon(Icons.check_rounded, color: Colors.white, size: 58),
                ),
              ),
            ),
            const SizedBox(height: 26),
            const Text('¡Pedido recibido!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: -0.6)),
            const SizedBox(height: 8),
            const Text(
              'Verificaremos tu pago y te avisaremos. Tu compra se libera en cuanto quede confirmado.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Palette.muted, height: 1.4),
            ),
            const SizedBox(height: 24),
            SoftCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('Estado', style: TextStyle(color: Palette.muted, fontWeight: FontWeight.w700)),
                      const Spacer(),
                      StatusChip(order.status),
                    ],
                  ),
                  const SizedBox(height: 14),
                  CopyRow(label: 'Código de pedido', value: order.code),
                  const SizedBox(height: 10),
                  CopyRow(label: order.method.isCrypto ? 'TXID' : 'Nº de transacción', value: order.reference),
                ],
              ),
            ),
            const SizedBox(height: 22),
            if (wa.isNotEmpty) ...[
              CoralButton(
                label: 'Enviar comprobante por WhatsApp',
                icon: Icons.send_rounded,
                onPressed: () async {
                  final url = 'https://wa.me/$wa?text=${Uri.encodeComponent(orderMessage(order))}';
                  final ok = await openUrl(url);
                  if (!ok && context.mounted) toast(context, 'No se pudo abrir WhatsApp');
                },
              ),
              const SizedBox(height: 12),
            ],
            OutlinedButton.icon(
              onPressed: () => copyText(context, orderMessage(order), 'Resumen del pedido'),
              icon: const Icon(Icons.copy_all_rounded, size: 18),
              label: const Text('Copiar resumen del pedido'),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst),
              child: const Text('Volver a la tienda'),
            ),
          ],
        ),
      ),
    );
  }
}
