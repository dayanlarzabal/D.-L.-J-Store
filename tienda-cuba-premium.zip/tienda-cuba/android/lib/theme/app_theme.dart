import 'package:flutter/material.dart';

/// Paleta tomada del logo de HANDMADE D.L.J STORE: azul marino profundo,
/// trazo coral y un dorado discreto para los detalles premium.
class Palette {
  static const navyDeep = Color(0xFF030F26);
  static const navy = Color(0xFF061C41);
  static const navySoft = Color(0xFF0E2B5C);
  static const coral = Color(0xFFF87171);
  static const coralDeep = Color(0xFFE5484D);
  static const gold = Color(0xFFE6C27A);
  static const bg = Color(0xFFF4F6FB);
  static const ink = Color(0xFF0B1630);
  static const muted = Color(0xFF6B7794);
  static const line = Color(0xFFE3E8F2);
  static const ok = Color(0xFF16A34A);
  static const warn = Color(0xFFF59E0B);
  static const danger = Color(0xFFDC2626);

  static const hero = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [navyDeep, navy, navySoft],
  );

  static const coralGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [coral, coralDeep],
  );
}

List<BoxShadow> softShadow([double opacity = 0.07]) => [
      BoxShadow(
        color: Palette.navy.withOpacity(opacity),
        blurRadius: 24,
        offset: const Offset(0, 10),
      ),
    ];

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: Palette.navy,
    primary: Palette.navy,
    secondary: Palette.coral,
    brightness: Brightness.light,
  );
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: Palette.bg,
  );
  return base.copyWith(
    textTheme: base.textTheme.apply(
      bodyColor: Palette.ink,
      displayColor: Palette.ink,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Palette.bg,
      foregroundColor: Palette.ink,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        color: Palette.ink,
        fontSize: 20,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.2,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      labelStyle: const TextStyle(color: Palette.muted),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Palette.line),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Palette.line),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Palette.navy, width: 1.6),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Palette.danger),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: Palette.navy,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(54),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: Palette.navy,
        minimumSize: const Size.fromHeight(50),
        side: const BorderSide(color: Palette.line, width: 1.4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      elevation: 12,
      height: 68,
      indicatorColor: Palette.coral.withOpacity(0.16),
      labelTextStyle: MaterialStateProperty.resolveWith((states) {
        final sel = states.contains(MaterialState.selected);
        return TextStyle(
          fontSize: 12,
          fontWeight: sel ? FontWeight.w800 : FontWeight.w600,
          color: sel ? Palette.navy : Palette.muted,
        );
      }),
      iconTheme: MaterialStateProperty.resolveWith((states) {
        final sel = states.contains(MaterialState.selected);
        return IconThemeData(color: sel ? Palette.navy : Palette.muted);
      }),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: Palette.navy,
      contentTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    dividerColor: Palette.line,
  );
}
