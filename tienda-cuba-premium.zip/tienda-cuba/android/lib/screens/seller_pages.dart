import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../models/models.dart';
import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';

// ───────────────────────── Acceso con PIN ─────────────────────────

class SellerGate extends StatelessWidget {
  const SellerGate({super.key});

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    if (store.sellerUnlocked) return const SellerDashboard();
    return _PinScreen(creating: !store.hasPin);
  }
}

class _PinScreen extends StatefulWidget {
  final bool creating;
  const _PinScreen({required this.creating});
  @override
  State<_PinScreen> createState() => _PinScreenState();
}

class _PinScreenState extends State<_PinScreen> {
  final pin = TextEditingController();
  final pin2 = TextEditingController();
  String? error;

  @override
  void dispose() {
    pin.dispose();
    pin2.dispose();
    super.dispose();
  }

  Future<void> _submit(AppStore store) async {
    final v = pin.text.trim();
    if (widget.creating) {
      if (v.length < 4) {
        setState(() => error = 'Usa al menos 4 dígitos');
        return;
      }
      if (v != pin2.text.trim()) {
        setState(() => error = 'Los PIN no coinciden');
        return;
      }
      await store.createPin(v);
      return;
    }
    final lock = store.lockRemaining;
    if (lock != null) {
      setState(() => error = 'Demasiados intentos. Espera ${lock.inSeconds} s.');
      return;
    }
    if (!store.tryPin(v)) {
      final l = store.lockRemaining;
      setState(() {
        error = l != null ? 'Demasiados intentos. Espera ${l.inSeconds} s.' : 'PIN incorrecto';
        pin.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Panel del vendedor')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 30),
        children: [
          const Center(child: BrandLogo(size: 84)),
          const SizedBox(height: 22),
          Text(widget.creating ? 'Crea tu PIN de vendedor' : 'Introduce tu PIN',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(
            widget.creating
                ? 'Protegerá tus pedidos, tarjetas y ajustes de cobro.'
                : 'Solo tú puedes verificar pagos y editar el catálogo.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Palette.muted, height: 1.4),
          ),
          const SizedBox(height: 26),
          TextField(
            controller: pin,
            obscureText: true,
            keyboardType: TextInputType.number,
            maxLength: 8,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 22, letterSpacing: 8, fontWeight: FontWeight.w800),
            decoration: fieldDec(widget.creating ? 'Nuevo PIN' : 'PIN').copyWith(counterText: ''),
            onSubmitted: (_) => _submit(store),
          ),
          if (widget.creating) ...[
            const SizedBox(height: 12),
            TextField(
              controller: pin2,
              obscureText: true,
              keyboardType: TextInputType.number,
              maxLength: 8,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, letterSpacing: 8, fontWeight: FontWeight.w800),
              decoration: fieldDec('Repite el PIN').copyWith(counterText: ''),
              onSubmitted: (_) => _submit(store),
            ),
          ],
          if (error != null) ...[
            const SizedBox(height: 10),
            Text(error!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Palette.danger, fontWeight: FontWeight.w700)),
          ],
          const SizedBox(height: 22),
          CoralButton(
            label: widget.creating ? 'Crear PIN y entrar' : 'Entrar',
            icon: Icons.lock_open_rounded,
            onPressed: () => _submit(store),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── Panel ─────────────────────────

class SellerDashboard extends StatelessWidget {
  const SellerDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Panel del vendedor'),
          actions: [
            IconButton(
              tooltip: 'Bloquear panel',
              icon: const Icon(Icons.lock_rounded),
              onPressed: () {
                store.lockSeller();
                Navigator.of(context).pop();
              },
            ),
          ],
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 14),
              child: Row(
                children: [
                  Expanded(
                    child: _Stat(
                        label: 'Ventas verificadas',
                        value: money(store.verifiedCUP, Cur.cup),
                        icon: Icons.trending_up_rounded),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _Stat(
                        label: 'Por verificar',
                        value: '${store.pendingCount}',
                        icon: Icons.hourglass_top_rounded,
                        accent: store.pendingCount > 0 ? Palette.warn : Palette.muted),
                  ),
                ],
              ),
            ),
            const TabBar(
              labelColor: Palette.navy,
              unselectedLabelColor: Palette.muted,
              indicatorColor: Palette.coral,
              labelStyle: TextStyle(fontWeight: FontWeight.w800),
              tabs: [Tab(text: 'Pedidos'), Tab(text: 'Catálogo'), Tab(text: 'Ajustes')],
            ),
            const Expanded(
              child: TabBarView(children: [_OrdersTab(), _CatalogTab(), _SettingsTab()]),
            ),
          ],
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color accent;
  const _Stat({required this.label, required this.value, required this.icon, this.accent = Palette.ok});

  @override
  Widget build(BuildContext context) {
    return SoftCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: accent, size: 22),
          const SizedBox(height: 8),
          Text(value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          Text(label, style: const TextStyle(color: Palette.muted, fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

// ───────────────────────── Pedidos ─────────────────────────

class _OrdersTab extends StatefulWidget {
  const _OrdersTab();
  @override
  State<_OrdersTab> createState() => _OrdersTabState();
}

class _OrdersTabState extends State<_OrdersTab> {
  OrderStatus? filter;

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final list = store.orders.where((o) => filter == null || o.status == filter).toList();

    return Column(
      children: [
        SizedBox(
          height: 58,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 6),
            children: [
              _FilterChip(label: 'Todos', selected: filter == null, onTap: () => setState(() => filter = null)),
              for (final s in OrderStatus.values)
                _FilterChip(
                  label: s.label,
                  selected: filter == s,
                  onTap: () => setState(() => filter = filter == s ? null : s),
                ),
            ],
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? const EmptyState(
                  icon: Icons.inbox_rounded,
                  title: 'Sin pedidos',
                  message: 'Los pedidos aparecerán aquí cuando un cliente confirme su pago.',
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) => _SellerOrderCard(order: list[i], store: store),
                ),
        ),
      ],
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onTap(),
        selectedColor: Palette.navy,
        labelStyle: TextStyle(
            color: selected ? Colors.white : Palette.ink, fontWeight: FontWeight.w700, fontSize: 13),
        showCheckmark: false,
        backgroundColor: Colors.white,
        side: const BorderSide(color: Palette.line),
      ),
    );
  }
}

class _SellerOrderCard extends StatelessWidget {
  final OrderRecord order;
  final AppStore store;
  const _SellerOrderCard({required this.order, required this.store});

  Future<void> _reject(BuildContext context) async {
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rechazar pago'),
        content: TextField(
          controller: note,
          maxLines: 2,
          decoration: fieldDec('Motivo (lo verá el cliente)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          FilledButton(
            style: FilledButton.styleFrom(
                backgroundColor: Palette.danger, minimumSize: const Size(100, 44)),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Rechazar'),
          ),
        ],
      ),
    );
    final text = note.text;
    if (ok == true) await store.setOrderStatus(order, OrderStatus.rejected, note: text);
  }

  @override
  Widget build(BuildContext context) {
    final o = order;
    final wa = onlyDigits(o.phone);
    return SoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(o.code,
                    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 0.4)),
              ),
              StatusChip(o.status),
            ],
          ),
          const SizedBox(height: 4),
          Text(formatDate(o.createdAt), style: const TextStyle(color: Palette.muted, fontSize: 12.5)),
          const SizedBox(height: 12),
          for (final l in o.lines)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text('• ${l.name}  ×${l.qty}', style: const TextStyle(fontWeight: FontWeight.w600)),
            ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: Text(o.method.label, style: const TextStyle(color: Palette.muted, fontWeight: FontWeight.w600))),
              Text('${moneyPlain(o.amount, o.method.decimals)} ${o.method.currencyCode}',
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            ],
          ),
          const SizedBox(height: 12),
          CopyRow(label: o.method.isCrypto ? 'TXID' : 'Nº de transacción', value: o.reference),
          if (o.method.isCrypto) ...[
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => openUrl('https://tronscan.org/#/transaction/${o.reference}'),
              icon: const Icon(Icons.open_in_new_rounded, size: 17),
              label: const Text('Ver en Tronscan'),
            ),
          ],
          const SizedBox(height: 12),
          Text('${o.customerName} · ${o.phone}', style: const TextStyle(fontWeight: FontWeight.w700)),
          if (o.address.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 3),
              child: Text(o.address, style: const TextStyle(color: Palette.muted, fontSize: 13)),
            ),
          if (o.fromWallet.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 3),
              child: Text('Wallet: ${shortAddress(o.fromWallet)}',
                  style: const TextStyle(color: Palette.muted, fontSize: 13)),
            ),
          const SizedBox(height: 14),
          if (o.status == OrderStatus.pending)
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                        foregroundColor: Palette.danger, minimumSize: const Size.fromHeight(48)),
                    onPressed: () => _reject(context),
                    child: const Text('Rechazar'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                        backgroundColor: Palette.ok, minimumSize: const Size.fromHeight(48)),
                    onPressed: () async {
                      await store.setOrderStatus(o, OrderStatus.verified);
                      if (context.mounted) toast(context, 'Pago verificado · descargas liberadas');
                    },
                    child: const Text('Verificar pago'),
                  ),
                ),
              ],
            ),
          if (o.status == OrderStatus.verified && o.hasPhysical)
            FilledButton(
              onPressed: () => store.setOrderStatus(o, OrderStatus.delivered),
              child: const Text('Marcar como entregado'),
            ),
          if (o.status == OrderStatus.rejected)
            OutlinedButton(
              onPressed: () => store.setOrderStatus(o, OrderStatus.pending),
              child: const Text('Reabrir para verificar'),
            ),
          if (wa.length >= 8) ...[
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: () => openUrl('https://wa.me/$wa'),
              icon: const Icon(Icons.chat_rounded, size: 18),
              label: const Text('Escribir al cliente por WhatsApp'),
            ),
          ],
        ],
      ),
    );
  }
}

// ───────────────────────── Catálogo ─────────────────────────

class _CatalogTab extends StatelessWidget {
  const _CatalogTab();

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      children: [
        CoralButton(
          label: 'Nuevo producto',
          icon: Icons.add_rounded,
          onPressed: () => Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const ProductFormPage())),
        ),
        const SizedBox(height: 16),
        if (store.products.isEmpty)
          const EmptyState(
            icon: Icons.inventory_2_outlined,
            title: 'Catálogo vacío',
            message: 'Añade tu primer producto para empezar a vender.',
          ),
        for (final p in store.products)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SoftCard(
              padding: const EdgeInsets.all(12),
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => ProductFormPage(product: p))),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: SizedBox(width: 62, height: 62, child: ProductImage(product: p, height: 62)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w800)),
                        const SizedBox(height: 2),
                        Text('${p.kind.label} · ${money(p.priceCUP, Cur.cup)}',
                            style: const TextStyle(color: Palette.muted, fontSize: 12.5)),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Eliminar',
                    icon: const Icon(Icons.delete_outline_rounded, color: Palette.danger),
                    onPressed: () async {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text('Eliminar producto'),
                          content: Text('¿Eliminar «${p.name}» del catálogo?'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
                            TextButton(
                                onPressed: () => Navigator.pop(ctx, true),
                                child: const Text('Eliminar', style: TextStyle(color: Palette.danger))),
                          ],
                        ),
                      );
                      if (ok == true) await store.deleteProduct(p.id);
                    },
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class ProductFormPage extends StatefulWidget {
  final Product? product;
  const ProductFormPage({super.key, this.product});
  @override
  State<ProductFormPage> createState() => _ProductFormPageState();
}

class _ProductFormPageState extends State<ProductFormPage> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController name, subtitle, description, cup, mlc, usdt, imageUrl, download, badge;
  late ProductKind kind;
  late bool digital;
  late bool featured;
  String imagePath = '';
  bool busy = false;

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    name = TextEditingController(text: p?.name ?? '');
    subtitle = TextEditingController(text: p?.subtitle ?? '');
    description = TextEditingController(text: p?.description ?? '');
    cup = TextEditingController(text: p == null ? '' : p.priceCUP.toStringAsFixed(0));
    mlc = TextEditingController(text: p == null ? '' : p.priceMLC.toString());
    usdt = TextEditingController(text: p == null ? '' : p.priceUSDT.toString());
    imageUrl = TextEditingController(text: p?.imageUrl ?? '');
    download = TextEditingController(text: p?.downloadUrl ?? '');
    badge = TextEditingController(text: p?.badge ?? '');
    kind = p?.kind ?? ProductKind.app;
    digital = p?.isDigital ?? true;
    featured = p?.featured ?? false;
    imagePath = p?.imagePath ?? '';
  }

  @override
  void dispose() {
    for (final c in [name, subtitle, description, cup, mlc, usdt, imageUrl, download, badge]) {
      c.dispose();
    }
    super.dispose();
  }

  double _num(TextEditingController c) => double.tryParse(c.text.trim().replaceAll(',', '.')) ?? 0;

  String? _price(String? v) {
    final n = double.tryParse((v ?? '').trim().replaceAll(',', '.'));
    return (n == null || n < 0) ? 'Precio no válido' : null;
  }

  Future<void> _pickImage(AppStore store) async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
      if (x == null) return;
      final saved = await store.persistImage(x.path);
      if (mounted) setState(() => imagePath = saved);
    } catch (_) {
      if (mounted) toast(context, 'No se pudo cargar la imagen');
    }
  }

  Future<void> _save(AppStore store) async {
    if (!_form.currentState!.validate()) return;
    setState(() => busy = true);
    final p = Product(
      id: widget.product?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      name: name.text.trim(),
      subtitle: subtitle.text.trim(),
      description: description.text.trim(),
      kind: kind,
      priceCUP: _num(cup),
      priceMLC: _num(mlc),
      priceUSDT: _num(usdt),
      imageUrl: imageUrl.text.trim(),
      imagePath: imagePath,
      downloadUrl: digital ? download.text.trim() : '',
      isDigital: digital,
      badge: badge.text.trim(),
      featured: featured,
    );
    await store.upsertProduct(p);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final preview = Product(
      id: 'preview',
      name: 'preview',
      kind: kind,
      priceCUP: 0,
      priceMLC: 0,
      priceUSDT: 0,
      isDigital: digital,
      imagePath: imagePath,
      imageUrl: imageUrl.text.trim(),
    );
    return Scaffold(
      appBar: AppBar(title: Text(widget.product == null ? 'Nuevo producto' : 'Editar producto')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
          children: [
            GestureDetector(
              onTap: () => _pickImage(store),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: Stack(
                  children: [
                    SizedBox(height: 190, width: double.infinity, child: ProductImage(product: preview, height: 190)),
                    Positioned(
                      right: 12,
                      bottom: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.95),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.photo_library_rounded, size: 18),
                            SizedBox(width: 6),
                            Text('Elegir foto', style: TextStyle(fontWeight: FontWeight.w800)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<ProductKind>(
              value: kind,
              decoration: fieldDec('Categoría', icon: Icons.category_rounded),
              items: [
                for (final k in ProductKind.values)
                  DropdownMenuItem(value: k, child: Text(k.label)),
              ],
              onChanged: (k) => setState(() {
                kind = k ?? kind;
                digital = kind.digitalByDefault;
              }),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: name,
              decoration: fieldDec('Nombre'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Escribe el nombre' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(controller: subtitle, decoration: fieldDec('Subtítulo', hint: 'Ej. Óleo · 75×50 cm')),
            const SizedBox(height: 12),
            TextFormField(controller: description, maxLines: 4, decoration: fieldDec('Descripción')),
            const SizedBox(height: 18),
            const Text('Precios', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                      controller: cup,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: fieldDec('CUP'),
                      validator: _price),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextFormField(
                      controller: mlc,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: fieldDec('MLC'),
                      validator: _price),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextFormField(
                      controller: usdt,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: fieldDec('USDT'),
                      validator: _price),
                ),
              ],
            ),
            const SizedBox(height: 14),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: digital,
              onChanged: (v) => setState(() => digital = v),
              title: const Text('Entrega digital', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Desactívalo para piezas físicas con envío'),
            ),
            if (digital) ...[
              TextFormField(
                controller: download,
                keyboardType: TextInputType.url,
                decoration: fieldDec('Enlace de descarga (APK)', icon: Icons.link_rounded),
              ),
              const SizedBox(height: 4),
              const Text('Solo se muestra al cliente cuando verificas su pago.',
                  style: TextStyle(color: Palette.muted, fontSize: 12.5)),
            ],
            const SizedBox(height: 14),
            TextFormField(
              controller: imageUrl,
              keyboardType: TextInputType.url,
              onChanged: (_) => setState(() {}),
              decoration: fieldDec('URL de imagen (opcional)', icon: Icons.image_outlined),
            ),
            const SizedBox(height: 12),
            TextFormField(controller: badge, decoration: fieldDec('Etiqueta', hint: 'Ej. Original, Popular, Pieza única')),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: featured,
              onChanged: (v) => setState(() => featured = v),
              title: const Text('Mostrar en Destacados', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
            const SizedBox(height: 14),
            CoralButton(
              label: busy ? 'Guardando…' : 'Guardar producto',
              icon: Icons.check_rounded,
              onPressed: busy ? null : () => _save(store),
            ),
          ],
        ),
      ),
    );
  }
}

// ───────────────────────── Ajustes de cobro ─────────────────────────

class _SettingsTab extends StatefulWidget {
  const _SettingsTab();
  @override
  State<_SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<_SettingsTab> {
  final _form = GlobalKey<FormState>();
  final business = TextEditingController();
  final whatsapp = TextEditingController();
  final cup = TextEditingController();
  final mlc = TextEditingController();
  final tron = TextEditingController();
  final trx = TextEditingController();
  bool _init = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_init) return;
    _init = true;
    final c = AppScope.of(context).cfg;
    business.text = c.businessName;
    whatsapp.text = c.whatsapp;
    cup.text = formatCard(c.cupCard);
    mlc.text = formatCard(c.mlcCard);
    tron.text = c.tronAddress;
    trx.text = c.trxPerUsdt > 0 ? c.trxPerUsdt.toString() : '';
  }

  @override
  void dispose() {
    for (final c in [business, whatsapp, cup, mlc, tron, trx]) {
      c.dispose();
    }
    super.dispose();
  }

  String? _card(String? v) {
    final d = onlyDigits(v ?? '');
    if (d.isEmpty) return null;
    return d.length == 16 ? null : 'La tarjeta debe tener 16 dígitos';
  }

  Future<void> _save(AppStore store) async {
    if (!_form.currentState!.validate()) return;
    final c = store.cfg;
    c.businessName = business.text.trim().isEmpty ? 'HANDMADE D.L.J STORE' : business.text.trim();
    c.whatsapp = onlyDigits(whatsapp.text);
    c.cupCard = onlyDigits(cup.text);
    c.mlcCard = onlyDigits(mlc.text);
    c.tronAddress = tron.text.trim();
    c.trxPerUsdt = double.tryParse(trx.text.trim().replaceAll(',', '.')) ?? 0;
    await store.saveConfig();
    if (mounted) toast(context, 'Ajustes de cobro guardados');
  }

  Future<void> _changePin(AppStore store) async {
    final a = TextEditingController();
    final b = TextEditingController();
    String? err;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Cambiar PIN'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                  controller: a,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  maxLength: 8,
                  decoration: fieldDec('Nuevo PIN').copyWith(counterText: '')),
              const SizedBox(height: 10),
              TextField(
                  controller: b,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  maxLength: 8,
                  decoration: fieldDec('Repite el PIN').copyWith(counterText: '', errorText: err)),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
              onPressed: () async {
                if (a.text.trim().length < 4) {
                  setD(() => err = 'Mínimo 4 dígitos');
                  return;
                }
                if (a.text.trim() != b.text.trim()) {
                  setD(() => err = 'No coinciden');
                  return;
                }
                await store.createPin(a.text.trim());
                if (ctx.mounted) Navigator.pop(ctx);
                if (mounted) toast(context, 'PIN actualizado');
              },
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 30),
        children: [
          const Text('Tu negocio', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          TextFormField(controller: business, decoration: fieldDec('Nombre de la tienda', icon: Icons.storefront_rounded)),
          const SizedBox(height: 12),
          TextFormField(
            controller: whatsapp,
            keyboardType: TextInputType.phone,
            decoration: fieldDec('WhatsApp con código de país', hint: '5351234567', icon: Icons.chat_rounded),
            validator: (v) {
              final d = onlyDigits(v ?? '');
              return d.isEmpty || (d.length >= 8 && d.length <= 15) ? null : 'Número no válido';
            },
          ),
          const SizedBox(height: 24),
          const Text('Transfermóvil', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text('Tarjetas donde recibes los pagos. Déjalas vacías para desactivar el método.',
              style: TextStyle(color: Palette.muted, fontSize: 12.5)),
          const SizedBox(height: 10),
          TextFormField(
            controller: cup,
            keyboardType: TextInputType.number,
            decoration: fieldDec('Tarjeta CUP', hint: '9225 0000 0000 0000', icon: Icons.credit_card_rounded),
            validator: _card,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: mlc,
            keyboardType: TextInputType.number,
            decoration: fieldDec('Tarjeta MLC', hint: '9225 0000 0000 0000', icon: Icons.credit_card_rounded),
            validator: _card,
          ),
          const SizedBox(height: 24),
          const Text('Crypto (red TRON)', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          TextFormField(
            controller: tron,
            decoration: fieldDec('Tu dirección TRON (T…)', icon: Icons.account_balance_wallet_rounded),
            validator: (v) {
              final a = (v ?? '').trim();
              return a.isEmpty || isValidTronAddress(a) ? null : 'Dirección TRON no válida';
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: trx,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: fieldDec('TRX por cada 1 USDT (opcional)', hint: 'Vacío = no aceptar TRX', icon: Icons.swap_horiz_rounded),
            validator: (v) {
              final t = (v ?? '').trim();
              if (t.isEmpty) return null;
              final n = double.tryParse(t.replaceAll(',', '.'));
              return (n == null || n <= 0) ? 'Tasa no válida' : null;
            },
          ),
          const SizedBox(height: 22),
          CoralButton(label: 'Guardar ajustes', icon: Icons.check_rounded, onPressed: () => _save(store)),
          const SizedBox(height: 22),
          OutlinedButton.icon(
            onPressed: () => _changePin(store),
            icon: const Icon(Icons.password_rounded, size: 18),
            label: const Text('Cambiar PIN'),
          ),
        ],
      ),
    );
  }
}
