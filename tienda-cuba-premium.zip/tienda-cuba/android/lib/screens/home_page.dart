import 'package:flutter/material.dart';

import '../models/models.dart';
import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';
import 'product_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String query = '';
  ProductKind? kind;

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final q = query.trim().toLowerCase();
    final filtered = store.products.where((p) {
      if (kind != null && p.kind != kind) return false;
      if (q.isEmpty) return true;
      return p.name.toLowerCase().contains(q) ||
          p.subtitle.toLowerCase().contains(q) ||
          p.description.toLowerCase().contains(q);
    }).toList();
    final featured = store.products.where((p) => p.featured).toList();
    final showFeatured = q.isEmpty && kind == null && featured.isNotEmpty;

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(child: _Header(
          store: store,
          onQuery: (v) => setState(() => query = v),
        )),
        SliverToBoxAdapter(child: _Categories(
          selected: kind,
          onSelect: (k) => setState(() => kind = k),
        )),
        if (showFeatured) ...[
          const SliverToBoxAdapter(child: _PromoBanner()),
          const SliverToBoxAdapter(child: SectionTitle('Destacados')),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 262,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                scrollDirection: Axis.horizontal,
                itemCount: featured.length,
                separatorBuilder: (_, __) => const SizedBox(width: 14),
                itemBuilder: (_, i) => SizedBox(
                  width: 168,
                  child: ProductCard(product: featured[i], heroScope: 'feat'),
                ),
              ),
            ),
          ),
        ],
        SliverToBoxAdapter(
          child: SectionTitle(kind == null ? 'Todo el catálogo' : kind!.plural),
        ),
        if (filtered.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.only(top: 30, bottom: 60),
              child: EmptyState(
                icon: Icons.search_off_rounded,
                title: 'Sin resultados',
                message: 'Prueba con otra palabra o elige otra categoría.',
              ),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: 0.68,
              ),
              delegate: SliverChildBuilderDelegate(
                (_, i) => ProductCard(product: filtered[i]),
                childCount: filtered.length,
              ),
            ),
          ),
      ],
    );
  }
}

class _Header extends StatelessWidget {
  final AppStore store;
  final ValueChanged<String> onQuery;
  const _Header({required this.store, required this.onQuery});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: Palette.hero,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
      ),
      padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + 14, 20, 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const BrandLogo(size: 46),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(store.cfg.businessName.toUpperCase(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.4)),
                    const Text('Apps · Arte · Artesanías',
                        style: TextStyle(color: Palette.gold, fontSize: 12, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          const Text('Descubre piezas\ncon identidad propia',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 27,
                  height: 1.15,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.6)),
          const SizedBox(height: 18),
          TextField(
            onChanged: onQuery,
            style: const TextStyle(fontWeight: FontWeight.w600),
            decoration: InputDecoration(
              hintText: 'Buscar apps, cuadros, lámparas…',
              prefixIcon: const Icon(Icons.search_rounded),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              const Text('Ver precios en',
                  style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
              const Spacer(),
              CurrencySwitch(value: store.currency, onChanged: store.setCurrency, dark: true),
            ],
          ),
        ],
      ),
    );
  }
}

class _Categories extends StatelessWidget {
  final ProductKind? selected;
  final ValueChanged<ProductKind?> onSelect;
  const _Categories({required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    Widget chip(String label, IconData icon, bool sel, VoidCallback onTap) {
      return GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
          decoration: BoxDecoration(
            color: sel ? Palette.navy : Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: sel ? null : softShadow(0.05),
          ),
          child: Row(
            children: [
              Icon(icon, size: 17, color: sel ? Colors.white : Palette.navy),
              const SizedBox(width: 7),
              Text(label,
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: sel ? Colors.white : Palette.ink)),
            ],
          ),
        ),
      );
    }

    return SizedBox(
      height: 76,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
        children: [
          chip('Todo', Icons.grid_view_rounded, selected == null, () => onSelect(null)),
          for (final k in ProductKind.values) ...[
            const SizedBox(width: 10),
            chip(k.plural, k.icon, selected == k, () => onSelect(selected == k ? null : k)),
          ],
        ],
      ),
    );
  }
}

class _PromoBanner extends StatelessWidget {
  const _PromoBanner();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
            colors: [Color(0xFFFFF1F1), Color(0xFFFFE0E0)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: Palette.coral.withOpacity(0.25)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Paga como te convenga',
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  const Text(
                    'Transfermóvil en CUP o MLC, o criptomonedas en red TRON.',
                    style: TextStyle(color: Palette.muted, height: 1.35),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: const [
                      Pill('CUP', icon: Icons.credit_card_rounded),
                      Pill('MLC', icon: Icons.credit_card_rounded),
                      Pill('USDT', icon: Icons.account_balance_wallet_rounded, color: Palette.coralDeep),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Icon(Icons.verified_user_rounded, size: 54, color: Palette.coral.withOpacity(0.85)),
          ],
        ),
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;
  final String heroScope;
  const ProductCard({super.key, required this.product, this.heroScope = 'grid'});

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final p = product;
    return GestureDetector(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(
            builder: (_) => ProductPage(product: p, heroTag: '$heroScope-${p.id}')),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          boxShadow: softShadow(),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Hero(tag: '$heroScope-${p.id}', child: ProductImage(product: p)),
                  if (p.badge.isNotEmpty)
                    Positioned(
                      left: 10,
                      top: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.95),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Text(p.badge,
                            style: const TextStyle(
                                fontSize: 11, fontWeight: FontWeight.w800, color: Palette.navy)),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 8, 10),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                        const SizedBox(height: 2),
                        Text(p.kind.label,
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: p.kind.accent)),
                        const SizedBox(height: 6),
                        Text(money(p.priceIn(store.currency), store.currency),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
                      ],
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      store.addToCart(p);
                      toast(context, '${p.name} añadido al carrito');
                    },
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        gradient: Palette.coralGradient,
                        borderRadius: BorderRadius.circular(13),
                      ),
                      child: const Icon(Icons.add_rounded, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
