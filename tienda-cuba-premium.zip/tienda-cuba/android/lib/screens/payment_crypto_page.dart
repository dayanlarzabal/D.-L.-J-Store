import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models/models.dart';
import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';
import 'checkout_page.dart';
import 'order_success_page.dart';
import 'wallet_page.dart';

class PaymentCryptoPage extends StatefulWidget {
  final PayMethod method;
  final CheckoutData data;
  const PaymentCryptoPage({super.key, required this.method, required this.data});
  @override
  State<PaymentCryptoPage> createState() => _PaymentCryptoPageState();
}

class _PaymentCryptoPageState extends State<PaymentCryptoPage> {
  final _form = GlobalKey<FormState>();
  final txid = TextEditingController();
  bool busy = false;

  @override
  void dispose() {
    txid.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text?.trim() ?? '';
    if (t.isEmpty) {
      if (mounted) toast(context, 'El portapapeles está vacío');
      return;
    }
    setState(() => txid.text = t);
  }

  Future<void> _openWallet(String address) async {
    final ok = await openUrl('tron:$address');
    if (!ok && mounted) {
      toast(context, 'No se encontró una wallet compatible. Copia la dirección y pégala en tu wallet.');
    }
  }

  Future<void> _submit(AppStore store) async {
    if (!_form.currentState!.validate()) return;
    setState(() => busy = true);
    final order = await store.createOrder(
      method: widget.method,
      reference: txid.text,
      name: widget.data.name,
      phone: widget.data.phone,
      address: widget.data.address,
      fromWallet: store.profile.wallet,
    );
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => OrderSuccessPage(order: order)),
      (r) => r.isFirst,
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final m = widget.method;
    final address = store.cfg.tronAddress.trim();
    final amount = store.amountFor(m);
    final isTrx = m == PayMethod.trx;
    final asset = isTrx ? 'TRX' : 'USDT';

    return Scaffold(
      appBar: AppBar(title: Text('Pagar con $asset')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: Palette.hero,
                borderRadius: BorderRadius.circular(26),
                boxShadow: softShadow(0.25),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Pill('Red TRON · TRC20', icon: Icons.hub_rounded, color: Palette.gold),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text('Envía exactamente',
                      style: TextStyle(color: Colors.white60, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Expanded(
                        child: Text('${amount.toStringAsFixed(2)} $asset',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 32,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -0.8)),
                      ),
                      IconButton.filled(
                        style: IconButton.styleFrom(backgroundColor: Colors.white.withOpacity(0.15)),
                        onPressed: () => copyText(context, amount.toStringAsFixed(2), 'Monto'),
                        icon: const Icon(Icons.copy_rounded, size: 20, color: Colors.white),
                      ),
                    ],
                  ),
                  if (isTrx) ...[
                    const SizedBox(height: 4),
                    Text('Tasa fijada por la tienda: 1 USDT = ${store.cfg.trxPerUsdt} TRX',
                        style: const TextStyle(color: Colors.white54, fontSize: 12.5)),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF4E5),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Palette.warn.withOpacity(0.4)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.warning_amber_rounded, color: Palette.warn),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      isTrx
                          ? 'Envía solo TRX por la red TRON. Otro activo u otra red puede perder los fondos para siempre.'
                          : 'Envía solo USDT por la red TRON (TRC20). Si usas otra red (ERC20, BEP20…) perderás los fondos.',
                      style: const TextStyle(height: 1.35, fontSize: 13.5, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            SoftCard(
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Palette.line),
                    ),
                    child: QrImageView(
                      data: address,
                      size: 190,
                      backgroundColor: Colors.white,
                      eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: Palette.navy),
                      dataModuleStyle: const QrDataModuleStyle(
                          dataModuleShape: QrDataModuleShape.square, color: Palette.navy),
                    ),
                  ),
                  const SizedBox(height: 14),
                  CopyRow(label: 'Dirección de la tienda', value: address, display: address),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: () => _openWallet(address),
                    icon: const Icon(Icons.open_in_new_rounded, size: 18),
                    label: const Text('Abrir mi wallet'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            _WalletBox(store: store, onChanged: () => setState(() {})),
            const SizedBox(height: 18),
            TextFormField(
              controller: txid,
              minLines: 1,
              maxLines: 3,
              decoration: fieldDec('TXID de la transacción',
                      hint: '64 caracteres hexadecimales', icon: Icons.tag_rounded)
                  .copyWith(
                suffixIcon: IconButton(
                  tooltip: 'Pegar',
                  icon: const Icon(Icons.content_paste_rounded),
                  onPressed: _paste,
                ),
              ),
              validator: (v) => isValidTxId(v ?? '')
                  ? null
                  : 'El TXID debe tener 64 caracteres hexadecimales (0-9, a-f)',
            ),
            const SizedBox(height: 8),
            const Text(
              'Lo encuentras en tu wallet, en el detalle de la transferencia enviada. '
              'Lo usamos para comprobar el pago en la blockchain.',
              style: TextStyle(color: Palette.muted, fontSize: 12.5, height: 1.35),
            ),
            const SizedBox(height: 18),
            CoralButton(
              label: busy ? 'Enviando…' : 'Ya envié · Verificar pago',
              icon: Icons.verified_user_rounded,
              onPressed: busy ? null : () => _submit(store),
            ),
          ],
        ),
      ),
    );
  }
}

class _WalletBox extends StatelessWidget {
  final AppStore store;
  final VoidCallback onChanged;
  const _WalletBox({required this.store, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final linked = store.profile.hasWallet;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: linked ? Palette.ok.withOpacity(0.5) : Palette.line),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: (linked ? Palette.ok : Palette.navy).withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              linked ? Icons.link_rounded : Icons.link_off_rounded,
              color: linked ? Palette.ok : Palette.navy,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(linked ? 'Wallet vinculada' : 'Vincula tu wallet',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(
                  linked
                      ? shortAddress(store.profile.wallet)
                      : 'Opcional: ayuda a identificar tu pago más rápido.',
                  style: const TextStyle(color: Palette.muted, fontSize: 12.5),
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const WalletPage()),
              );
              onChanged();
            },
            child: Text(linked ? 'Cambiar' : 'Vincular'),
          ),
        ],
      ),
    );
  }
}
