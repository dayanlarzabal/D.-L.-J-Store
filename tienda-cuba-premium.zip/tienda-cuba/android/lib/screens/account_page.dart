import 'package:flutter/material.dart';

import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';
import 'seller_pages.dart';
import 'wallet_page.dart';

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final p = store.profile;
    final name = p.name.trim().isEmpty ? 'Invitado' : p.name.trim();

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        Container(
          decoration: const BoxDecoration(
            gradient: Palette.hero,
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
          ),
          padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + 20, 20, 28),
          child: Row(
            children: [
              CircleAvatar(
                radius: 34,
                backgroundColor: Palette.coral,
                child: Text(name.characters.first.toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900)),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name,
                        style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 3),
                    Text(p.phone.isEmpty ? 'Completa tu perfil para comprar más rápido' : p.phone,
                        style: const TextStyle(color: Colors.white70, fontSize: 13.5)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SectionTitle('Mi cuenta'),
        _Tile(
          icon: Icons.person_rounded,
          title: 'Mis datos',
          subtitle: 'Nombre, teléfono y dirección de entrega',
          onTap: () => _editProfile(context, store),
        ),
        _Tile(
          icon: Icons.account_balance_wallet_rounded,
          title: 'Mi wallet',
          subtitle: p.hasWallet ? 'Vinculada · ${shortAddress(p.wallet)}' : 'Vincula tu wallet TRON para pagar en crypto',
          trailing: p.hasWallet ? const Icon(Icons.verified_rounded, color: Palette.ok) : null,
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const WalletPage())),
        ),
        _Tile(
          icon: Icons.payments_rounded,
          title: 'Moneda de los precios',
          subtitle: 'Se aplica en toda la tienda',
          trailing: CurrencySwitch(value: store.currency, onChanged: store.setCurrency),
        ),
        const SectionTitle('Negocio'),
        _Tile(
          icon: Icons.admin_panel_settings_rounded,
          title: 'Panel del vendedor',
          subtitle: store.pendingCount > 0
              ? '${store.pendingCount} pedido(s) por verificar'
              : 'Catálogo, pedidos, pagos y ajustes',
          trailing: store.pendingCount > 0
              ? Badge(label: Text('${store.pendingCount}'))
              : const Icon(Icons.chevron_right_rounded),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SellerGate())),
        ),
        const SectionTitle('Información'),
        const _Tile(
          icon: Icons.info_rounded,
          title: 'HANDMADE D.L.J STORE',
          subtitle: 'Versión 2.0 · Apps, juegos, arte, pintura, escultura y artesanías',
        ),
        const SizedBox(height: 30),
      ],
    );
  }

  void _editProfile(BuildContext context, AppStore store) {
    final name = TextEditingController(text: store.profile.name);
    final phone = TextEditingController(text: store.profile.phone);
    final address = TextEditingController(text: store.profile.address);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Palette.bg,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(22, 22, 22, MediaQuery.of(ctx).viewInsets.bottom + 22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Mis datos', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            TextField(controller: name, decoration: fieldDec('Nombre', icon: Icons.person_outline_rounded)),
            const SizedBox(height: 12),
            TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: fieldDec('Teléfono / WhatsApp', icon: Icons.phone_outlined)),
            const SizedBox(height: 12),
            TextField(
                controller: address,
                maxLines: 2,
                decoration: fieldDec('Dirección de entrega', icon: Icons.location_on_outlined)),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: () async {
                store.profile
                  ..name = name.text.trim()
                  ..phone = phone.text.trim()
                  ..address = address.text.trim();
                await store.saveProfile();
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  const _Tile({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
      child: SoftCard(
        onTap: onTap,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Palette.navy.withOpacity(0.07),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: Palette.navy),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(color: Palette.muted, fontSize: 12.5, height: 1.3)),
                ],
              ),
            ),
            if (trailing != null) ...[const SizedBox(width: 8), trailing!]
            else if (onTap != null) const Icon(Icons.chevron_right_rounded, color: Palette.muted),
          ],
        ),
      ),
    );
  }
}
