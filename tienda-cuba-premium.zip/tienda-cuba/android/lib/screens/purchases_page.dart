import 'package:flutter/material.dart';

import '../models/models.dart';
import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';

class PurchasesPage extends StatefulWidget {
  const PurchasesPage({super.key});
  @override
  State<PurchasesPage> createState() => _PurchasesPageState();
}

class _PurchasesPageState extends State<PurchasesPage> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Mis compras')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
            child: SegmentedButton<int>(
              showSelectedIcon: false,
              style: SegmentedButton.styleFrom(
                selectedBackgroundColor: Palette.navy,
                selectedForegroundColor: Colors.white,
              ),
              segments: [
                ButtonSegment(value: 0, label: Text('Pedidos (${store.orders.length})')),
                ButtonSegment(value: 1, label: Text('Descargas (${store.unlockedDownloads.length})')),
              ],
              selected: {tab},
              onSelectionChanged: (s) => setState(() => tab = s.first),
            ),
          ),
          Expanded(child: tab == 0 ? _Orders(store: store) : _Downloads(store: store)),
        ],
      ),
    );
  }
}

class _Orders extends StatelessWidget {
  final AppStore store;
  const _Orders({required this.store});

  @override
  Widget build(BuildContext context) {
    if (store.orders.isEmpty) {
      return const EmptyState(
        icon: Icons.receipt_long_outlined,
        title: 'Aún no tienes pedidos',
        message: 'Cuando compres algo, aquí verás el estado de tu pago y tus descargas.',
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
      itemCount: store.orders.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) => OrderCard(order: store.orders[i]),
    );
  }
}

class OrderCard extends StatelessWidget {
  final OrderRecord order;
  const OrderCard({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    final o = order;
    return SoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(o.code,
                    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 0.4)),
              ),
              StatusChip(o.status),
            ],
          ),
          const SizedBox(height: 4),
          Text(formatDate(o.createdAt), style: const TextStyle(color: Palette.muted, fontSize: 12.5)),
          const Divider(height: 24),
          for (final l in o.lines)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: [
                  Icon(l.kind.icon, size: 18, color: l.kind.accent),
                  const SizedBox(width: 10),
                  Expanded(child: Text('${l.name}  ×${l.qty}', style: const TextStyle(fontWeight: FontWeight.w600))),
                ],
              ),
            ),
          const SizedBox(height: 6),
          Row(
            children: [
              Text(o.method.label, style: const TextStyle(color: Palette.muted, fontWeight: FontWeight.w600)),
              const Spacer(),
              Text('${moneyPlain(o.amount, o.method.decimals)} ${o.method.currencyCode}',
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            ],
          ),
          if (o.status == OrderStatus.pending) ...[
            const SizedBox(height: 12),
            const _Note(
              icon: Icons.hourglass_top_rounded,
              color: Palette.warn,
              text: 'Estamos verificando tu pago. Si tardamos, envía el comprobante por WhatsApp.',
            ),
          ],
          if (o.status == OrderStatus.rejected) ...[
            const SizedBox(height: 12),
            _Note(
              icon: Icons.info_rounded,
              color: Palette.danger,
              text: o.sellerNote.isEmpty
                  ? 'No pudimos confirmar el pago. Contáctanos para revisarlo.'
                  : 'Motivo: ${o.sellerNote}',
            ),
          ],
        ],
      ),
    );
  }
}

class _Note extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String text;
  const _Note({required this.icon, required this.color, required this.text});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 18, color: color),
            const SizedBox(width: 8),
            Expanded(child: Text(text, style: const TextStyle(fontSize: 13, height: 1.35))),
          ],
        ),
      );
}

class _Downloads extends StatelessWidget {
  final AppStore store;
  const _Downloads({required this.store});

  @override
  Widget build(BuildContext context) {
    final items = store.unlockedDownloads;
    final waiting = store.orders
        .where((o) => o.status == OrderStatus.pending && o.hasDigital)
        .length;

    if (items.isEmpty) {
      return EmptyState(
        icon: Icons.lock_clock_rounded,
        title: 'Sin descargas disponibles',
        message: waiting > 0
            ? 'Tienes $waiting pedido(s) esperando verificación. Tus descargas aparecerán aquí en cuanto se confirme el pago.'
            : 'Las apps y juegos que compres aparecerán aquí cuando se verifique tu pago.',
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        final it = items[i];
        return SoftCard(
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: it.line.kind.accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(it.line.kind.icon, color: it.line.kind.accent),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(it.line.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
                    const SizedBox(height: 2),
                    Text('Pedido ${it.order.code}',
                        style: const TextStyle(color: Palette.muted, fontSize: 12.5)),
                  ],
                ),
              ),
              IconButton.filledTonal(
                tooltip: 'Copiar enlace',
                onPressed: () => copyText(context, it.line.downloadUrl, 'Enlace'),
                icon: const Icon(Icons.copy_rounded, size: 19),
              ),
              const SizedBox(width: 4),
              IconButton.filled(
                tooltip: 'Descargar',
                style: IconButton.styleFrom(backgroundColor: Palette.coral),
                onPressed: () async {
                  final ok = await openUrl(it.line.downloadUrl);
                  if (!ok && context.mounted) toast(context, 'No se pudo abrir el enlace');
                },
                icon: const Icon(Icons.download_rounded, size: 20, color: Colors.white),
              ),
            ],
          ),
        );
      },
    );
  }
}
