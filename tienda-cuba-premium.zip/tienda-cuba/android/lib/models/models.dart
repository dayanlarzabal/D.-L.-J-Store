import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

// ───────────────────────── Monedas ─────────────────────────

enum Cur { cup, mlc, usdt }

extension CurX on Cur {
  String get code => switch (this) {
        Cur.cup => 'CUP',
        Cur.mlc => 'MLC',
        Cur.usdt => 'USDT',
      };
  int get decimals => this == Cur.cup ? 0 : 2;
}

// ───────────────────────── Catálogo ─────────────────────────

enum ProductKind { app, game, art, painting, sculpture, craft }

extension ProductKindX on ProductKind {
  String get label => switch (this) {
        ProductKind.app => 'App',
        ProductKind.game => 'Juego',
        ProductKind.art => 'Arte',
        ProductKind.painting => 'Pintura',
        ProductKind.sculpture => 'Escultura',
        ProductKind.craft => 'Artesanía',
      };

  String get plural => switch (this) {
        ProductKind.app => 'Apps',
        ProductKind.game => 'Juegos',
        ProductKind.art => 'Arte',
        ProductKind.painting => 'Pinturas',
        ProductKind.sculpture => 'Esculturas',
        ProductKind.craft => 'Artesanías',
      };

  IconData get icon => switch (this) {
        ProductKind.app => Icons.phone_android_rounded,
        ProductKind.game => Icons.sports_esports_rounded,
        ProductKind.art => Icons.auto_awesome_rounded,
        ProductKind.painting => Icons.palette_rounded,
        ProductKind.sculpture => Icons.architecture_rounded,
        ProductKind.craft => Icons.handyman_rounded,
      };

  Color get accent => switch (this) {
        ProductKind.app => const Color(0xFF4F46E5),
        ProductKind.game => const Color(0xFFF59E0B),
        ProductKind.art => const Color(0xFF9333EA),
        ProductKind.painting => const Color(0xFFE5484D),
        ProductKind.sculpture => const Color(0xFF92400E),
        ProductKind.craft => const Color(0xFF0D9488),
      };

  bool get digitalByDefault => this == ProductKind.app || this == ProductKind.game;
}

class Product {
  final String id;
  final String name;
  final String subtitle;
  final String description;
  final ProductKind kind;
  final double priceCUP;
  final double priceMLC;
  final double priceUSDT;
  final String imageUrl;
  final String imagePath;
  final String downloadUrl;
  final bool isDigital;
  final String badge;
  final bool featured;

  const Product({
    required this.id,
    required this.name,
    this.subtitle = '',
    this.description = '',
    required this.kind,
    required this.priceCUP,
    required this.priceMLC,
    required this.priceUSDT,
    this.imageUrl = '',
    this.imagePath = '',
    this.downloadUrl = '',
    required this.isDigital,
    this.badge = '',
    this.featured = false,
  });

  double priceIn(Cur c) => switch (c) {
        Cur.cup => priceCUP,
        Cur.mlc => priceMLC,
        Cur.usdt => priceUSDT,
      };

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'subtitle': subtitle,
        'description': description,
        'kind': kind.name,
        'priceCUP': priceCUP,
        'priceMLC': priceMLC,
        'priceUSDT': priceUSDT,
        'imageUrl': imageUrl,
        'imagePath': imagePath,
        'downloadUrl': downloadUrl,
        'isDigital': isDigital,
        'badge': badge,
        'featured': featured,
      };

  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'] as String,
        name: j['name'] as String,
        subtitle: (j['subtitle'] as String?) ?? '',
        description: (j['description'] as String?) ?? '',
        kind: ProductKind.values.firstWhere(
          (e) => e.name == j['kind'],
          orElse: () => ProductKind.app,
        ),
        priceCUP: (j['priceCUP'] as num?)?.toDouble() ?? 0,
        priceMLC: (j['priceMLC'] as num?)?.toDouble() ?? 0,
        priceUSDT: (j['priceUSDT'] as num?)?.toDouble() ?? 0,
        imageUrl: (j['imageUrl'] as String?) ?? '',
        imagePath: (j['imagePath'] as String?) ?? '',
        downloadUrl: (j['downloadUrl'] as String?) ?? '',
        isDigital: (j['isDigital'] as bool?) ?? true,
        badge: (j['badge'] as String?) ?? '',
        featured: (j['featured'] as bool?) ?? false,
      );
}

class CartItem {
  final Product product;
  int qty;
  CartItem(this.product, [this.qty = 1]);
}

// ───────────────────────── Configuración del vendedor ─────────────────────────

class StoreConfig {
  String businessName;
  String whatsapp; // solo dígitos con código de país, p. ej. 5351234567
  String cupCard;
  String mlcCard;
  String tronAddress;
  double trxPerUsdt; // 0 = TRX desactivado
  String pinHash;
  String pinSalt;

  StoreConfig({
    this.businessName = 'HANDMADE D.L.J STORE',
    this.whatsapp = '',
    this.cupCard = '',
    this.mlcCard = '',
    this.tronAddress = '',
    this.trxPerUsdt = 0,
    this.pinHash = '',
    this.pinSalt = '',
  });

  bool get hasCup => cupCard.trim().isNotEmpty;
  bool get hasMlc => mlcCard.trim().isNotEmpty;
  bool get hasTron => tronAddress.trim().isNotEmpty;
  bool get hasTrx => hasTron && trxPerUsdt > 0;
  bool get hasWhatsapp => whatsapp.trim().isNotEmpty;

  Map<String, dynamic> toJson() => {
        'businessName': businessName,
        'whatsapp': whatsapp,
        'cupCard': cupCard,
        'mlcCard': mlcCard,
        'tronAddress': tronAddress,
        'trxPerUsdt': trxPerUsdt,
        'pinHash': pinHash,
        'pinSalt': pinSalt,
      };

  factory StoreConfig.fromJson(Map<String, dynamic> j) => StoreConfig(
        businessName: (j['businessName'] as String?) ?? 'HANDMADE D.L.J STORE',
        whatsapp: (j['whatsapp'] as String?) ?? '',
        cupCard: (j['cupCard'] as String?) ?? '',
        mlcCard: (j['mlcCard'] as String?) ?? '',
        tronAddress: (j['tronAddress'] as String?) ?? '',
        trxPerUsdt: (j['trxPerUsdt'] as num?)?.toDouble() ?? 0,
        pinHash: (j['pinHash'] as String?) ?? '',
        pinSalt: (j['pinSalt'] as String?) ?? '',
      );
}

// ───────────────────────── Cliente ─────────────────────────

class CustomerProfile {
  String name;
  String phone;
  String address;
  String wallet; // dirección TRON vinculada (T...)

  CustomerProfile({
    this.name = '',
    this.phone = '',
    this.address = '',
    this.wallet = '',
  });

  bool get hasWallet => wallet.trim().isNotEmpty;

  Map<String, dynamic> toJson() =>
      {'name': name, 'phone': phone, 'address': address, 'wallet': wallet};

  factory CustomerProfile.fromJson(Map<String, dynamic> j) => CustomerProfile(
        name: (j['name'] as String?) ?? '',
        phone: (j['phone'] as String?) ?? '',
        address: (j['address'] as String?) ?? '',
        wallet: (j['wallet'] as String?) ?? '',
      );
}

// ───────────────────────── Pedidos ─────────────────────────

enum PayMethod { transfermovilCup, transfermovilMlc, usdtTrc20, trx }

extension PayMethodX on PayMethod {
  String get label => switch (this) {
        PayMethod.transfermovilCup => 'Transfermóvil CUP',
        PayMethod.transfermovilMlc => 'Transfermóvil MLC',
        PayMethod.usdtTrc20 => 'USDT · TRC20',
        PayMethod.trx => 'TRX · TRON',
      };

  String get currencyCode => switch (this) {
        PayMethod.transfermovilCup => 'CUP',
        PayMethod.transfermovilMlc => 'MLC',
        PayMethod.usdtTrc20 => 'USDT',
        PayMethod.trx => 'TRX',
      };

  bool get isCrypto => this == PayMethod.usdtTrc20 || this == PayMethod.trx;

  int get decimals => this == PayMethod.transfermovilCup ? 0 : 2;
}

enum OrderStatus { pending, verified, rejected, delivered }

extension OrderStatusX on OrderStatus {
  String get label => switch (this) {
        OrderStatus.pending => 'Pendiente de verificación',
        OrderStatus.verified => 'Pago verificado',
        OrderStatus.rejected => 'Pago rechazado',
        OrderStatus.delivered => 'Entregado',
      };

  Color get color => switch (this) {
        OrderStatus.pending => Palette.warn,
        OrderStatus.verified => Palette.ok,
        OrderStatus.rejected => Palette.danger,
        OrderStatus.delivered => const Color(0xFF2563EB),
      };

  IconData get icon => switch (this) {
        OrderStatus.pending => Icons.hourglass_top_rounded,
        OrderStatus.verified => Icons.verified_rounded,
        OrderStatus.rejected => Icons.cancel_rounded,
        OrderStatus.delivered => Icons.local_shipping_rounded,
      };

  /// Los enlaces de descarga solo se liberan con el pago confirmado.
  bool get unlocksDownloads =>
      this == OrderStatus.verified || this == OrderStatus.delivered;
}

class OrderLine {
  final String productId;
  final String name;
  final ProductKind kind;
  final int qty;
  final double unitCUP;
  final double unitMLC;
  final double unitUSDT;
  final bool isDigital;
  final String downloadUrl;

  const OrderLine({
    required this.productId,
    required this.name,
    required this.kind,
    required this.qty,
    required this.unitCUP,
    required this.unitMLC,
    required this.unitUSDT,
    required this.isDigital,
    required this.downloadUrl,
  });

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'name': name,
        'kind': kind.name,
        'qty': qty,
        'unitCUP': unitCUP,
        'unitMLC': unitMLC,
        'unitUSDT': unitUSDT,
        'isDigital': isDigital,
        'downloadUrl': downloadUrl,
      };

  factory OrderLine.fromJson(Map<String, dynamic> j) => OrderLine(
        productId: (j['productId'] as String?) ?? '',
        name: (j['name'] as String?) ?? '',
        kind: ProductKind.values.firstWhere(
          (e) => e.name == j['kind'],
          orElse: () => ProductKind.app,
        ),
        qty: (j['qty'] as num?)?.toInt() ?? 1,
        unitCUP: (j['unitCUP'] as num?)?.toDouble() ?? 0,
        unitMLC: (j['unitMLC'] as num?)?.toDouble() ?? 0,
        unitUSDT: (j['unitUSDT'] as num?)?.toDouble() ?? 0,
        isDigital: (j['isDigital'] as bool?) ?? true,
        downloadUrl: (j['downloadUrl'] as String?) ?? '',
      );
}

class OrderRecord {
  final String id;
  final String code;
  final List<OrderLine> lines;
  final PayMethod method;
  final double amount; // monto en la moneda del método de pago
  final String reference; // nº de transacción Transfermóvil o TXID
  final String customerName;
  final String phone;
  final String address;
  final String fromWallet;
  final DateTime createdAt;
  OrderStatus status;
  String sellerNote;

  OrderRecord({
    required this.id,
    required this.code,
    required this.lines,
    required this.method,
    required this.amount,
    required this.reference,
    required this.customerName,
    required this.phone,
    this.address = '',
    this.fromWallet = '',
    required this.createdAt,
    this.status = OrderStatus.pending,
    this.sellerNote = '',
  });

  bool get hasPhysical => lines.any((l) => !l.isDigital);
  bool get hasDigital => lines.any((l) => l.isDigital && l.downloadUrl.isNotEmpty);
  double get totalCUP => lines.fold(0.0, (s, l) => s + l.unitCUP * l.qty);

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'lines': lines.map((e) => e.toJson()).toList(),
        'method': method.name,
        'amount': amount,
        'reference': reference,
        'customerName': customerName,
        'phone': phone,
        'address': address,
        'fromWallet': fromWallet,
        'createdAt': createdAt.toIso8601String(),
        'status': status.name,
        'sellerNote': sellerNote,
      };

  factory OrderRecord.fromJson(Map<String, dynamic> j) => OrderRecord(
        id: j['id'] as String,
        code: (j['code'] as String?) ?? (j['id'] as String),
        lines: ((j['lines'] as List?) ?? [])
            .map((e) => OrderLine.fromJson(e as Map<String, dynamic>))
            .toList(),
        method: PayMethod.values.firstWhere(
          (e) => e.name == j['method'],
          orElse: () => PayMethod.transfermovilCup,
        ),
        amount: (j['amount'] as num?)?.toDouble() ?? 0,
        reference: (j['reference'] as String?) ?? '',
        customerName: (j['customerName'] as String?) ?? '',
        phone: (j['phone'] as String?) ?? '',
        address: (j['address'] as String?) ?? '',
        fromWallet: (j['fromWallet'] as String?) ?? '',
        createdAt: DateTime.parse(j['createdAt'] as String),
        status: OrderStatus.values.firstWhere(
          (e) => e.name == j['status'],
          orElse: () => OrderStatus.pending,
        ),
        sellerNote: (j['sellerNote'] as String?) ?? '',
      );
}
