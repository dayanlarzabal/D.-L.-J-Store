import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/models.dart';

final _cupFmt = NumberFormat('#,##0', 'en_US');
final _decFmt = NumberFormat('#,##0.00', 'en_US');

String money(double v, Cur c) =>
    '${c == Cur.cup ? _cupFmt.format(v) : _decFmt.format(v)} ${c.code}';

String moneyPlain(double v, int decimals) =>
    decimals == 0 ? _cupFmt.format(v) : _decFmt.format(v);

String formatDate(DateTime d) => DateFormat('dd/MM/yyyy · HH:mm').format(d);

/// Agrupa una tarjeta en bloques de 4 dígitos: 9225 0000 0000 0000
String formatCard(String raw) {
  final digits = raw.replaceAll(RegExp(r'\D'), '');
  final buf = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && i % 4 == 0) buf.write(' ');
    buf.write(digits[i]);
  }
  return buf.toString();
}

String onlyDigits(String s) => s.replaceAll(RegExp(r'\D'), '');

String shortAddress(String a) =>
    a.length <= 14 ? a : '${a.substring(0, 6)}…${a.substring(a.length - 6)}';

const _tokenAlphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
final _rng = Random.secure();

String randomToken(int len) =>
    List.generate(len, (_) => _tokenAlphabet[_rng.nextInt(_tokenAlphabet.length)]).join();

/// Valida una dirección TRON (Base58Check, prefijo 0x41, 34 caracteres que
/// empiezan por «T»). Detecta errores de tecleo antes de que alguien envíe dinero.
bool isValidTronAddress(String address) {
  const alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  final a = address.trim();
  if (a.length != 34 || a[0] != 'T') return false;
  var n = BigInt.zero;
  final base = BigInt.from(58);
  for (final ch in a.split('')) {
    final i = alphabet.indexOf(ch);
    if (i < 0) return false;
    n = n * base + BigInt.from(i);
  }
  final bytes = List<int>.filled(25, 0);
  final mask = BigInt.from(0xff);
  for (var i = 24; i >= 0; i--) {
    bytes[i] = (n & mask).toInt();
    n = n >> 8;
  }
  if (n != BigInt.zero || bytes[0] != 0x41) return false;
  final check = sha256.convert(sha256.convert(bytes.sublist(0, 21)).bytes).bytes;
  for (var i = 0; i < 4; i++) {
    if (check[i] != bytes[21 + i]) return false;
  }
  return true;
}

bool isValidTxId(String s) => RegExp(r'^[0-9a-fA-F]{64}$').hasMatch(s.trim());

void toast(BuildContext context, String message) {
  final m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(content: Text(message)));
}

Future<void> copyText(BuildContext context, String text, [String what = 'Copiado']) async {
  await Clipboard.setData(ClipboardData(text: text));
  HapticFeedback.lightImpact();
  if (context.mounted) toast(context, '$what al portapapeles');
}

Future<bool> openUrl(String url) async {
  try {
    return await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  } catch (_) {
    return false;
  }
}
