import 'package:flutter/material.dart';

import '../models/models.dart';
import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';
import 'checkout_page.dart';

class CartPage extends StatelessWidget {
  const CartPage({super.key});

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final cur = store.currency;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mi carrito'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(child: CurrencySwitch(value: cur, onChanged: store.setCurrency)),
          ),
        ],
      ),
      body: store.cart.isEmpty
          ? const EmptyState(
              icon: Icons.shopping_bag_outlined,
              title: 'Tu carrito está vacío',
              message: 'Explora la tienda y añade apps, juegos o piezas de arte.',
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
                    itemCount: store.cart.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (_, i) => _CartRow(item: store.cart[i], store: store),
                  ),
                ),
                _Summary(store: store),
              ],
            ),
    );
  }
}

class _CartRow extends StatelessWidget {
  final CartItem item;
  final AppStore store;
  const _CartRow({required this.item, required this.store});

  @override
  Widget build(BuildContext context) {
    final p = item.product;
    final cur = store.currency;
    return Dismissible(
      key: ValueKey('cart-${p.id}'),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => store.removeFromCart(item),
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 24),
        decoration: BoxDecoration(
          color: Palette.danger,
          borderRadius: BorderRadius.circular(22),
        ),
        child: const Icon(Icons.delete_rounded, color: Colors.white),
      ),
      child: SoftCard(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SizedBox(width: 78, height: 78, child: ProductImage(product: p, height: 78)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text(p.isDigital ? 'Entrega digital' : 'Envío físico',
                      style: const TextStyle(color: Palette.muted, fontSize: 12.5, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Text(money(p.priceIn(cur) * item.qty, cur),
                      style: const TextStyle(fontWeight: FontWeight.w900)),
                ],
              ),
            ),
            Container(
              decoration: BoxDecoration(
                color: Palette.bg,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                children: [
                  _QtyButton(icon: Icons.add_rounded, onTap: () => store.changeQty(item, 1)),
                  Text('${item.qty}', style: const TextStyle(fontWeight: FontWeight.w800)),
                  _QtyButton(icon: Icons.remove_rounded, onTap: () => store.changeQty(item, -1)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QtyButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _QtyButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(padding: const EdgeInsets.all(7), child: Icon(icon, size: 18)),
      );
}

class _Summary extends StatelessWidget {
  final AppStore store;
  const _Summary({required this.store});

  @override
  Widget build(BuildContext context) {
    final cur = store.currency;
    return Container(
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        boxShadow: [
          BoxShadow(color: Palette.navy.withOpacity(0.08), blurRadius: 24, offset: const Offset(0, -8)),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                const Text('Total', style: TextStyle(color: Palette.muted, fontWeight: FontWeight.w700)),
                const Spacer(),
                Text(money(store.cartTotal(cur), cur),
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
              ],
            ),
            const SizedBox(height: 4),
            Align(
              alignment: Alignment.centerRight,
              child: Text(
                [
                  for (final c in Cur.values.where((c) => c != cur)) money(store.cartTotal(c), c),
                ].join('  ·  '),
                style: const TextStyle(color: Palette.muted, fontSize: 12.5, fontWeight: FontWeight.w600),
              ),
            ),
            const SizedBox(height: 16),
            CoralButton(
              label: 'Continuar al pago',
              icon: Icons.lock_rounded,
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const CheckoutPage()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
