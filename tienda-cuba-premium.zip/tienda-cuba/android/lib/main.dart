import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'screens/shell.dart';
import 'state/app_store.dart';
import 'theme/app_theme.dart';
import 'widgets/common.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const DljStoreApp());
}

class DljStoreApp extends StatefulWidget {
  const DljStoreApp({super.key});
  @override
  State<DljStoreApp> createState() => _DljStoreAppState();
}

class _DljStoreAppState extends State<DljStoreApp> {
  final AppStore store = AppStore();
  bool ready = false;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await Future.wait([
      store.load(),
      Future.delayed(const Duration(milliseconds: 1600)),
    ]);
    if (mounted) setState(() => ready = true);
  }

  @override
  void dispose() {
    store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      store: store,
      child: MaterialApp(
        title: 'HANDMADE D.L.J STORE',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: AnimatedSwitcher(
          duration: const Duration(milliseconds: 500),
          child: ready ? const MainShell(key: ValueKey('shell')) : const _Splash(key: ValueKey('splash')),
        ),
      ),
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: Palette.hero),
        child: Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.0, end: 1.0),
            duration: const Duration(milliseconds: 900),
            curve: Curves.easeOutCubic,
            builder: (context, t, child) => Opacity(
              opacity: t,
              child: Transform.scale(scale: 0.85 + 0.15 * t, child: child),
            ),
            child: const Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                BrandLogo(size: 120),
                SizedBox(height: 26),
                Text('HANDMADE D.L.J',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 3)),
                SizedBox(height: 6),
                Text('STORE',
                    style: TextStyle(
                        color: Palette.gold,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 8)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
