import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';

/// Vincula la wallet TRON del cliente a su cuenta. La dirección se valida
/// (Base58Check) para evitar errores de tecleo; la app nunca pide claves privadas.
class WalletPage extends StatefulWidget {
  const WalletPage({super.key});
  @override
  State<WalletPage> createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  final ctrl = TextEditingController();
  String? error;
  bool _init = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_init) return;
    _init = true;
    ctrl.text = AppScope.of(context).profile.wallet;
  }

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    if (d?.text != null) setState(() => ctrl.text = d!.text!.trim());
  }

  Future<void> _save(AppStore store) async {
    final a = ctrl.text.trim();
    if (!isValidTronAddress(a)) {
      setState(() => error = 'Dirección TRON no válida. Debe empezar por T y tener 34 caracteres.');
      return;
    }
    store.profile.wallet = a;
    await store.saveProfile();
    if (!mounted) return;
    toast(context, 'Wallet vinculada correctamente');
    Navigator.of(context).pop();
  }

  Future<void> _unlink(AppStore store) async {
    store.profile.wallet = '';
    await store.saveProfile();
    if (!mounted) return;
    toast(context, 'Wallet desvinculada');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Mi wallet')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: Palette.hero,
              borderRadius: BorderRadius.circular(26),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.account_balance_wallet_rounded, color: Palette.gold, size: 34),
                SizedBox(height: 14),
                Text('Vincula tu wallet TRON',
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                SizedBox(height: 6),
                Text(
                  'Pega la dirección pública de tu wallet (TronLink, Trust Wallet, etc.) '
                  'para que tus pagos en USDT o TRX se identifiquen más rápido.',
                  style: TextStyle(color: Colors.white70, height: 1.4),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: ctrl,
            minLines: 1,
            maxLines: 2,
            onChanged: (_) => setState(() => error = null),
            decoration: fieldDec('Dirección pública (T…)', icon: Icons.link_rounded).copyWith(
              errorText: error,
              suffixIcon: IconButton(
                tooltip: 'Pegar',
                icon: const Icon(Icons.content_paste_rounded),
                onPressed: _paste,
              ),
            ),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFEAF7EF),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.lock_rounded, color: Palette.ok, size: 20),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Solo guardamos la dirección pública. Nunca te pediremos tu frase semilla ni tu clave privada.',
                    style: TextStyle(height: 1.35, fontSize: 13.5, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          CoralButton(label: 'Guardar wallet', icon: Icons.check_rounded, onPressed: () => _save(store)),
          if (store.profile.hasWallet) ...[
            const SizedBox(height: 12),
            OutlinedButton(onPressed: () => _unlink(store), child: const Text('Desvincular wallet')),
          ],
        ],
      ),
    );
  }
}
