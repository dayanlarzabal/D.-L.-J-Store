import 'package:flutter/material.dart';

import '../models/models.dart';
import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';
import 'checkout_page.dart';
import 'order_success_page.dart';

class PaymentTransfermovilPage extends StatefulWidget {
  final PayMethod method;
  final CheckoutData data;
  const PaymentTransfermovilPage({super.key, required this.method, required this.data});
  @override
  State<PaymentTransfermovilPage> createState() => _PaymentTransfermovilPageState();
}

class _PaymentTransfermovilPageState extends State<PaymentTransfermovilPage> {
  final _form = GlobalKey<FormState>();
  final ref = TextEditingController();
  bool confirmed = false;
  bool busy = false;

  @override
  void dispose() {
    ref.dispose();
    super.dispose();
  }

  Future<void> _submit(AppStore store) async {
    if (!_form.currentState!.validate()) return;
    if (!confirmed) {
      toast(context, 'Confirma que hiciste la transferencia por el monto exacto');
      return;
    }
    setState(() => busy = true);
    final order = await store.createOrder(
      method: widget.method,
      reference: ref.text,
      name: widget.data.name,
      phone: widget.data.phone,
      address: widget.data.address,
    );
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => OrderSuccessPage(order: order)),
      (r) => r.isFirst,
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final m = widget.method;
    final isCup = m == PayMethod.transfermovilCup;
    final card = isCup ? store.cfg.cupCard : store.cfg.mlcCard;
    final amount = store.amountFor(m);
    final amountText = moneyPlain(amount, m.decimals);

    return Scaffold(
      appBar: AppBar(title: Text(m.label)),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
          children: [
            _BankCard(
              holder: store.cfg.businessName,
              number: formatCard(card),
              currency: m.currencyCode,
            ),
            const SizedBox(height: 18),
            SoftCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Monto exacto a transferir',
                      style: TextStyle(color: Palette.muted, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Expanded(
                        child: Text('$amountText ${m.currencyCode}',
                            style: const TextStyle(
                                fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: -0.8)),
                      ),
                      IconButton.filledTonal(
                        onPressed: () => copyText(context, amount.toStringAsFixed(m.decimals), 'Monto'),
                        icon: const Icon(Icons.copy_rounded, size: 20),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  CopyRow(
                    label: 'Tarjeta destino',
                    value: onlyDigits(card),
                    display: formatCard(card),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            const Text('Cómo pagar', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            const _Step(n: 1, text: 'Abre Transfermóvil y elige «Transferir».'),
            const _Step(n: 2, text: 'Pega la tarjeta destino y envía el monto exacto.'),
            const _Step(n: 3, text: 'Copia el número de transacción del SMS o comprobante.'),
            const _Step(n: 4, text: 'Pégalo aquí abajo y confirma. Verificaremos tu pago.'),
            const SizedBox(height: 18),
            TextFormField(
              controller: ref,
              keyboardType: TextInputType.text,
              decoration: fieldDec('Nº de transacción de Transfermóvil',
                  hint: 'Ej. 1234567890', icon: Icons.tag_rounded),
              validator: (v) => (v == null || v.trim().length < 6)
                  ? 'Escribe el número de transacción (mínimo 6 caracteres)'
                  : null,
            ),
            const SizedBox(height: 10),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              value: confirmed,
              onChanged: (v) => setState(() => confirmed = v ?? false),
              title: const Text('Transferí el monto exacto a la tarjeta indicada',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            ),
            const SizedBox(height: 12),
            CoralButton(
              label: busy ? 'Enviando…' : 'Ya pagué · Enviar a verificación',
              icon: Icons.verified_user_rounded,
              onPressed: busy ? null : () => _submit(store),
            ),
          ],
        ),
      ),
    );
  }
}

class _BankCard extends StatelessWidget {
  final String holder;
  final String number;
  final String currency;
  const _BankCard({required this.holder, required this.number, required this.currency});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: Palette.hero,
        borderRadius: BorderRadius.circular(26),
        boxShadow: [
          BoxShadow(color: Palette.navy.withOpacity(0.35), blurRadius: 26, offset: const Offset(0, 14)),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: -40,
            top: -50,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Palette.coral.withOpacity(0.18),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 42,
                    height: 30,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(7),
                      gradient: const LinearGradient(colors: [Palette.gold, Color(0xFFB8914A)]),
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.14),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Text(currency,
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w800, letterSpacing: 1)),
                  ),
                ],
              ),
              const Spacer(),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(number,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        letterSpacing: 2.4,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'monospace')),
              ),
              const SizedBox(height: 14),
              const Text('TITULAR / DESTINO',
                  style: TextStyle(color: Colors.white54, fontSize: 10, letterSpacing: 1.6)),
              const SizedBox(height: 2),
              Text(holder.toUpperCase(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
            ],
          ),
        ],
      ),
    );
  }
}

class _Step extends StatelessWidget {
  final int n;
  final String text;
  const _Step({required this.n, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 26,
            height: 26,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Palette.coral.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Text('$n',
                style: const TextStyle(
                    color: Palette.coralDeep, fontWeight: FontWeight.w800, fontSize: 13)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 3),
              child: Text(text, style: const TextStyle(height: 1.35, fontSize: 14.5)),
            ),
          ),
        ],
      ),
    );
  }
}
