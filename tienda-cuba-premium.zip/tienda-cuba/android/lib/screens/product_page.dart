import 'package:flutter/material.dart';

import '../models/models.dart';
import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';

class ProductPage extends StatelessWidget {
  final Product product;
  final String? heroTag;
  const ProductPage({super.key, required this.product, this.heroTag});

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final p = product;
    final cur = store.currency;

    return Scaffold(
      backgroundColor: Palette.bg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 360,
            backgroundColor: Palette.navy,
            automaticallyImplyLeading: false,
            leading: Padding(
              padding: const EdgeInsets.all(8),
              child: CircleAvatar(
                backgroundColor: Colors.white,
                child: IconButton(
                  icon: const Icon(Icons.arrow_back_rounded, color: Palette.ink),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Hero(
                tag: heroTag ?? 'grid-${p.id}',
                child: ProductImage(product: p, height: 360),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Transform.translate(
              offset: const Offset(0, -24),
              child: Container(
                decoration: const BoxDecoration(
                  color: Palette.bg,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
                ),
                padding: const EdgeInsets.fromLTRB(22, 24, 22, 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        Pill(p.kind.label, icon: p.kind.icon, color: p.kind.accent),
                        if (p.badge.isNotEmpty)
                          Pill(p.badge, icon: Icons.workspace_premium_rounded, color: Palette.coralDeep),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Text(p.name,
                        style: const TextStyle(
                            fontSize: 28, fontWeight: FontWeight.w900, height: 1.1, letterSpacing: -0.6)),
                    if (p.subtitle.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(p.subtitle,
                          style: const TextStyle(color: Palette.muted, fontSize: 15, fontWeight: FontWeight.w600)),
                    ],
                    const SizedBox(height: 20),
                    SoftCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Text('Precio',
                                  style: TextStyle(color: Palette.muted, fontWeight: FontWeight.w700)),
                              const Spacer(),
                              CurrencySwitch(value: cur, onChanged: store.setCurrency),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(money(p.priceIn(cur), cur),
                              style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: -0.8)),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 14,
                            children: [
                              for (final c in Cur.values.where((c) => c != cur))
                                Text(money(p.priceIn(c), c),
                                    style: const TextStyle(color: Palette.muted, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),
                    const Text('Descripción',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Text(
                      p.description.isEmpty ? 'Sin descripción.' : p.description,
                      style: const TextStyle(height: 1.5, color: Color(0xFF3B4663), fontSize: 15),
                    ),
                    const SizedBox(height: 22),
                    _InfoTile(
                      icon: p.isDigital ? Icons.bolt_rounded : Icons.local_shipping_rounded,
                      title: p.isDigital ? 'Entrega digital' : 'Envío dentro de Cuba',
                      text: p.isDigital
                          ? 'El enlace de descarga se libera en tu cuenta cuando se verifica el pago.'
                          : 'Coordinaremos la entrega contigo por teléfono o WhatsApp.',
                    ),
                    const SizedBox(height: 10),
                    const _InfoTile(
                      icon: Icons.shield_moon_rounded,
                      title: 'Pago verificado',
                      text: 'Cada pago se comprueba manualmente antes de entregar tu compra.',
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(color: Palette.navy.withOpacity(0.08), blurRadius: 20, offset: const Offset(0, -6)),
            ],
          ),
          child: CoralButton(
            label: 'Agregar al carrito',
            icon: Icons.shopping_bag_rounded,
            onPressed: () {
              store.addToCart(p);
              toast(context, '${p.name} añadido al carrito');
            },
          ),
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  const _InfoTile({required this.icon, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Palette.line),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Palette.navy.withOpacity(0.07),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: Palette.navy, size: 21),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(text, style: const TextStyle(color: Palette.muted, height: 1.35, fontSize: 13.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
