import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/models.dart';
import '../utils/helpers.dart';

List<Product> seedProducts() => const [
      Product(
        id: 'seed-app-1',
        name: 'Gestor de Ventas Pro',
        subtitle: 'Android · Productividad',
        description:
            'Controla inventario, ventas y ganancias desde tu teléfono, sin internet. '
            'Recibirás el enlace del APK en cuanto se verifique tu pago.',
        kind: ProductKind.app,
        priceCUP: 3500,
        priceMLC: 12,
        priceUSDT: 12,
        downloadUrl: '',
        isDigital: true,
        badge: 'Popular',
        featured: true,
      ),
      Product(
        id: 'seed-game-1',
        name: 'Habana Runner',
        subtitle: 'Android · Aventura',
        description: 'Corre por las calles de La Habana esquivando obstáculos. APK tras verificar el pago.',
        kind: ProductKind.game,
        priceCUP: 1500,
        priceMLC: 5,
        priceUSDT: 5,
        isDigital: true,
        badge: 'Top',
        featured: true,
      ),
      Product(
        id: 'seed-craft-1',
        name: 'Lámpara PVC LED pintada',
        subtitle: 'Pieza hecha a mano · LED',
        description:
            'Lámpara de PVC calado y pintada a mano, con iluminación LED. Cada pieza es única. '
            'Envío físico dentro de Cuba.',
        kind: ProductKind.craft,
        priceCUP: 9500,
        priceMLC: 30,
        priceUSDT: 30,
        isDigital: false,
        badge: 'Hecho a mano',
        featured: true,
      ),
      Product(
        id: 'seed-paint-1',
        name: 'Esencia cubana',
        subtitle: 'Óleo sobre lienzo · 75×50 cm',
        description: 'Pintura original firmada por el artista. Envío físico en Cuba.',
        kind: ProductKind.painting,
        priceCUP: 85000,
        priceMLC: 270,
        priceUSDT: 270,
        isDigital: false,
        badge: 'Original',
        featured: true,
      ),
      Product(
        id: 'seed-sculpt-1',
        name: 'Figura en relieve',
        subtitle: 'Escultura artesanal',
        description: 'Escultura modelada a mano con acabado artístico. Envío físico en Cuba.',
        kind: ProductKind.sculpture,
        priceCUP: 24000,
        priceMLC: 75,
        priceUSDT: 75,
        isDigital: false,
        badge: 'Pieza única',
      ),
      Product(
        id: 'seed-art-1',
        name: 'Grabado artístico',
        subtitle: 'Edición limitada',
        description: 'Grabado impreso de forma artesanal en edición limitada y numerada.',
        kind: ProductKind.art,
        priceCUP: 12000,
        priceMLC: 38,
        priceUSDT: 38,
        isDigital: false,
        badge: 'Edición limitada',
      ),
    ];

class AppStore extends ChangeNotifier {
  List<Product> products = [];
  final List<CartItem> cart = [];
  StoreConfig cfg = StoreConfig();
  CustomerProfile profile = CustomerProfile();
  List<OrderRecord> orders = [];
  Cur currency = Cur.cup;
  bool loaded = false;

  // Sesión del vendedor (solo en memoria).
  bool sellerUnlocked = false;
  int _failedPin = 0;
  DateTime? _lockedUntil;

  static const _kProducts = 'djl2_products';
  static const _kCfg = 'djl2_cfg';
  static const _kProfile = 'djl2_profile';
  static const _kOrders = 'djl2_orders';
  static const _kCurrency = 'djl2_currency';

  // ─────────── Carga / guardado ───────────

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    try {
      final raw = p.getString(_kProducts);
      if (raw != null && raw.isNotEmpty) {
        products = (jsonDecode(raw) as List)
            .map((e) => Product.fromJson(e as Map<String, dynamic>))
            .toList();
      } else {
        products = seedProducts();
        await _saveProducts();
      }
      final c = p.getString(_kCfg);
      if (c != null) cfg = StoreConfig.fromJson(jsonDecode(c) as Map<String, dynamic>);
      final pr = p.getString(_kProfile);
      if (pr != null) profile = CustomerProfile.fromJson(jsonDecode(pr) as Map<String, dynamic>);
      final o = p.getString(_kOrders);
      if (o != null) {
        orders = (jsonDecode(o) as List)
            .map((e) => OrderRecord.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      final cur = p.getString(_kCurrency);
      currency = Cur.values.firstWhere((e) => e.name == cur, orElse: () => Cur.cup);
    } catch (_) {
      // Si algún dato guardado está dañado, arrancamos con el catálogo base.
      if (products.isEmpty) products = seedProducts();
    }
    loaded = true;
    notifyListeners();
  }

  Future<void> _saveProducts() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kProducts, jsonEncode(products.map((e) => e.toJson()).toList()));
  }

  Future<void> _saveOrders() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kOrders, jsonEncode(orders.map((e) => e.toJson()).toList()));
  }

  Future<void> saveConfig() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kCfg, jsonEncode(cfg.toJson()));
    notifyListeners();
  }

  Future<void> saveProfile() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kProfile, jsonEncode(profile.toJson()));
    notifyListeners();
  }

  Future<void> setCurrency(Cur c) async {
    currency = c;
    final p = await SharedPreferences.getInstance();
    await p.setString(_kCurrency, c.name);
    notifyListeners();
  }

  // ─────────── Catálogo ───────────

  Future<void> upsertProduct(Product product) async {
    final i = products.indexWhere((e) => e.id == product.id);
    if (i >= 0) {
      products[i] = product;
    } else {
      products.insert(0, product);
    }
    await _saveProducts();
    notifyListeners();
  }

  Future<void> deleteProduct(String id) async {
    products.removeWhere((e) => e.id == id);
    cart.removeWhere((c) => c.product.id == id);
    await _saveProducts();
    notifyListeners();
  }

  /// Copia la imagen elegida a la carpeta de la app para que no se pierda.
  Future<String> persistImage(String sourcePath) async {
    final dir = await getApplicationDocumentsDirectory();
    final ext = sourcePath.contains('.') ? sourcePath.split('.').last : 'jpg';
    final dest = '${dir.path}/img_${DateTime.now().millisecondsSinceEpoch}.$ext';
    await File(sourcePath).copy(dest);
    return dest;
  }

  // ─────────── Carrito ───────────

  void addToCart(Product product) {
    final ex = cart.where((c) => c.product.id == product.id);
    if (ex.isNotEmpty) {
      ex.first.qty++;
    } else {
      cart.add(CartItem(product));
    }
    notifyListeners();
  }

  void changeQty(CartItem item, int delta) {
    item.qty += delta;
    if (item.qty <= 0) cart.remove(item);
    notifyListeners();
  }

  void removeFromCart(CartItem item) {
    cart.remove(item);
    notifyListeners();
  }

  int get cartCount => cart.fold(0, (s, i) => s + i.qty);
  double cartTotal(Cur c) => cart.fold(0.0, (s, i) => s + i.product.priceIn(c) * i.qty);
  bool get cartHasPhysical => cart.any((c) => !c.product.isDigital);

  // ─────────── Pedidos ───────────

  double amountFor(PayMethod m) => switch (m) {
        PayMethod.transfermovilCup => cartTotal(Cur.cup),
        PayMethod.transfermovilMlc => cartTotal(Cur.mlc),
        PayMethod.usdtTrc20 => cartTotal(Cur.usdt),
        PayMethod.trx => cartTotal(Cur.usdt) * cfg.trxPerUsdt,
      };

  Future<OrderRecord> createOrder({
    required PayMethod method,
    required String reference,
    required String name,
    required String phone,
    String address = '',
    String fromWallet = '',
  }) async {
    final order = OrderRecord(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      code: 'DLJ-${randomToken(6)}',
      lines: cart
          .map((c) => OrderLine(
                productId: c.product.id,
                name: c.product.name,
                kind: c.product.kind,
                qty: c.qty,
                unitCUP: c.product.priceCUP,
                unitMLC: c.product.priceMLC,
                unitUSDT: c.product.priceUSDT,
                isDigital: c.product.isDigital,
                downloadUrl: c.product.downloadUrl,
              ))
          .toList(),
      method: method,
      amount: amountFor(method),
      reference: reference.trim(),
      customerName: name.trim(),
      phone: phone.trim(),
      address: address.trim(),
      fromWallet: fromWallet.trim(),
      createdAt: DateTime.now(),
    );
    orders.insert(0, order);
    cart.clear();
    profile
      ..name = name.trim()
      ..phone = phone.trim();
    if (address.trim().isNotEmpty) profile.address = address.trim();
    await _saveOrders();
    await saveProfile();
    return order;
  }

  Future<void> setOrderStatus(OrderRecord o, OrderStatus s, {String note = ''}) async {
    o.status = s;
    if (note.trim().isNotEmpty) o.sellerNote = note.trim();
    await _saveOrders();
    notifyListeners();
  }

  /// Descargas liberadas: solo de pedidos con pago verificado por el vendedor.
  List<({OrderRecord order, OrderLine line})> get unlockedDownloads => [
        for (final o in orders)
          if (o.status.unlocksDownloads)
            for (final l in o.lines)
              if (l.isDigital && l.downloadUrl.isNotEmpty) (order: o, line: l),
      ];

  int get pendingCount => orders.where((o) => o.status == OrderStatus.pending).length;
  double get verifiedCUP => orders
      .where((o) => o.status.unlocksDownloads)
      .fold(0.0, (s, o) => s + o.totalCUP);

  // ─────────── PIN del vendedor ───────────

  bool get hasPin => cfg.pinHash.isNotEmpty;

  String _hash(String pin, String salt) =>
      sha256.convert(utf8.encode('$salt:$pin')).toString();

  Duration? get lockRemaining {
    final l = _lockedUntil;
    if (l == null) return null;
    final d = l.difference(DateTime.now());
    return d.isNegative ? null : d;
  }

  Future<void> createPin(String pin) async {
    cfg.pinSalt = randomToken(16);
    cfg.pinHash = _hash(pin, cfg.pinSalt);
    sellerUnlocked = true;
    await saveConfig();
  }

  bool tryPin(String pin) {
    if (lockRemaining != null) return false;
    if (_hash(pin, cfg.pinSalt) == cfg.pinHash) {
      _failedPin = 0;
      sellerUnlocked = true;
      notifyListeners();
      return true;
    }
    _failedPin++;
    if (_failedPin >= 5) {
      _failedPin = 0;
      _lockedUntil = DateTime.now().add(const Duration(seconds: 60));
    }
    return false;
  }

  void lockSeller() {
    sellerUnlocked = false;
    notifyListeners();
  }
}

class AppScope extends InheritedNotifier<AppStore> {
  const AppScope({super.key, required AppStore store, required super.child})
      : super(notifier: store);

  static AppStore of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope no encontrado');
    return scope!.notifier!;
  }
}
