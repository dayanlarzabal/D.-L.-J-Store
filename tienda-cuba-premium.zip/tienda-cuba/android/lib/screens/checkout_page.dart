import 'package:flutter/material.dart';

import '../models/models.dart';
import '../state/app_store.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/common.dart';
import 'payment_crypto_page.dart';
import 'payment_transfermovil_page.dart';

class CheckoutPage extends StatefulWidget {
  const CheckoutPage({super.key});
  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  final _form = GlobalKey<FormState>();
  final name = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  PayMethod? method;
  bool _prefilled = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_prefilled) return;
    _prefilled = true;
    final prof = AppScope.of(context).profile;
    name.text = prof.name;
    phone.text = prof.phone;
    address.text = prof.address;
  }

  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    address.dispose();
    super.dispose();
  }

  bool _available(AppStore s, PayMethod m) => switch (m) {
        PayMethod.transfermovilCup => s.cfg.hasCup,
        PayMethod.transfermovilMlc => s.cfg.hasMlc,
        PayMethod.usdtTrc20 => s.cfg.hasTron,
        PayMethod.trx => s.cfg.hasTrx,
      };

  void _continue(AppStore store) {
    if (!_form.currentState!.validate()) return;
    if (method == null) {
      toast(context, 'Elige un método de pago');
      return;
    }
    final data = CheckoutData(
      name: name.text,
      phone: phone.text,
      address: store.cartHasPhysical ? address.text : '',
    );
    final page = method!.isCrypto
        ? PaymentCryptoPage(method: method!, data: data)
        : PaymentTransfermovilPage(method: method!, data: data);
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final physical = store.cartHasPhysical;

    return Scaffold(
      appBar: AppBar(title: const Text('Finalizar compra')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
          children: [
            const _StepLabel(n: '1', text: 'Tus datos'),
            const SizedBox(height: 12),
            TextFormField(
              controller: name,
              textCapitalization: TextCapitalization.words,
              decoration: fieldDec('Nombre completo', icon: Icons.person_outline_rounded),
              validator: (v) => (v == null || v.trim().length < 3) ? 'Escribe tu nombre' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: phone,
              keyboardType: TextInputType.phone,
              decoration: fieldDec('Teléfono / WhatsApp', icon: Icons.phone_outlined),
              validator: (v) => onlyDigits(v ?? '').length < 8 ? 'Teléfono no válido' : null,
            ),
            if (physical) ...[
              const SizedBox(height: 12),
              TextFormField(
                controller: address,
                maxLines: 2,
                decoration: fieldDec('Dirección de entrega',
                    hint: 'Provincia, municipio, calle y número', icon: Icons.location_on_outlined),
                validator: (v) => (v == null || v.trim().length < 8) ? 'Escribe la dirección de entrega' : null,
              ),
            ],
            const SizedBox(height: 28),
            const _StepLabel(n: '2', text: 'Método de pago'),
            const SizedBox(height: 12),
            for (final m in PayMethod.values) ...[
              if (m != PayMethod.trx || store.cfg.hasTrx)
                _MethodTile(
                  method: m,
                  amount: store.amountFor(m),
                  available: _available(store, m),
                  selected: method == m,
                  onTap: () => setState(() => method = m),
                ),
            ],
            const SizedBox(height: 22),
            SoftCard(
              child: Row(
                children: [
                  const Text('Total a pagar',
                      style: TextStyle(color: Palette.muted, fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Text(
                    method == null
                        ? '—'
                        : '${moneyPlain(store.amountFor(method!), method!.decimals)} ${method!.currencyCode}',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            CoralButton(
              label: 'Continuar',
              icon: Icons.arrow_forward_rounded,
              onPressed: () => _continue(store),
            ),
          ],
        ),
      ),
    );
  }
}

class CheckoutData {
  final String name;
  final String phone;
  final String address;
  const CheckoutData({required this.name, required this.phone, required this.address});
}

class _StepLabel extends StatelessWidget {
  final String n;
  final String text;
  const _StepLabel({required this.n, required this.text});

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: const BoxDecoration(color: Palette.navy, shape: BoxShape.circle),
            child: Text(n,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
          ),
          const SizedBox(width: 10),
          Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        ],
      );
}

class _MethodTile extends StatelessWidget {
  final PayMethod method;
  final double amount;
  final bool available;
  final bool selected;
  final VoidCallback onTap;
  const _MethodTile({
    required this.method,
    required this.amount,
    required this.available,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final icon = method.isCrypto ? Icons.account_balance_wallet_rounded : Icons.credit_card_rounded;
    final subtitle = !available
        ? 'No disponible por ahora'
        : method.isCrypto
            ? 'Red TRON · confirmación en blockchain'
            : 'Transferencia desde Transfermóvil';
    final decimals = method.decimals;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Opacity(
        opacity: available ? 1 : 0.5,
        child: GestureDetector(
          onTap: available ? onTap : () => toast(context, 'El vendedor aún no configuró este método'),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: selected ? Palette.coral : Palette.line,
                width: selected ? 2 : 1,
              ),
              boxShadow: selected ? softShadow(0.1) : null,
            ),
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: (method.isCrypto ? Palette.coral : Palette.navy).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(icon, color: method.isCrypto ? Palette.coralDeep : Palette.navy),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(method.label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: const TextStyle(color: Palette.muted, fontSize: 12.5)),
                    ],
                  ),
                ),
                if (available)
                  Text('${moneyPlain(amount, decimals)} ${method.currencyCode}',
                      style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(width: 6),
                Icon(
                  selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                  color: selected ? Palette.coral : Palette.line,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
